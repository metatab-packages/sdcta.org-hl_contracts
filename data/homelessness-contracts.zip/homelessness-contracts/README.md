This dataset lives in: https://www.tagtog.net/SDTEF/homelessness-contracts

This zip was generated with:
  * date: _2021-08-11T20:06:38.009Z_
  * search: `folder:0`
  * total found documents: **121**

The dataset is here written in the [anndoc format](https://docs.tagtog.net/anndoc.html). Use the `annotations-legend.json` file to help you interpret the annotations.


What great things will you do with the dataset? :-) Enjoy!
