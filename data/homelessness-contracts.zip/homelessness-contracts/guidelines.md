### Annotation Guidelines
------
 _Define the team rules of what and how to annotate_


**You can use [markdown syntax](https://commonmark.org/help/)**


